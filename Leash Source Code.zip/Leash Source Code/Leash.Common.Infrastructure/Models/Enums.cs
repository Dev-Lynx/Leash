﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leash.Common.Infrastructure.Models
{
    public enum Roles { Header, Heeler }
    public enum ExportTypes { Excel, CSV, Text }
}
