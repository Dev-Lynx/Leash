﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Leash.Common.Infrastructure.Resources.Controls
{
    public class NumberTextBox : TextBox
    {
        #region Properties
        
        #endregion

        #region Constructors
        public NumberTextBox()
        {

        }
        #endregion

        #region Methods
        #endregion  

    }
}
